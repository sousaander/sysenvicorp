<div class="space-y-6">
    <!-- Cabeçalho do Módulo -->
    <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
            <h1 class="text-2xl font-bold text-slate-800 dark:text-white tracking-tight">Dashboard Jurídico</h1>
            <p class="text-sm text-slate-500 dark:text-slate-400 font-medium">Controle de processos judiciais, administrativos e prazos fatais.</p>
        </div>
        <div class="flex gap-2">
            <?php if (has_permission('juridico_processos_manage')) : ?>
                <a href="<?= BASE_URL ?>/juridico/processos/novo" class="sys-btn-primary !bg-purple-600 hover:!bg-purple-700 !py-2 !px-4">
                    <i class='bx bx-plus mr-2'></i> Novo Processo
                </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Grid de Indicadores (KPIs) -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <!-- Card: Processos Ativos -->
        <div class="sys-card border-l-4 border-purple-500 !p-5 flex items-center gap-4 group hover:shadow-md transition-all">
            <div class="icon-box-3d item-purple">
                <i class='bx bxs-briefcase'></i>
            </div>
            <div>
                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Processos Ativos</p>
                <h3 class="text-2xl font-black text-slate-800 dark:text-white leading-none"><?= $totalProcessosAtivos ?></h3>
            </div>
        </div>

        <!-- Card: Prazos na Semana -->
        <div class="sys-card border-l-4 border-amber-500 !p-5 flex items-center gap-4 group hover:shadow-md transition-all">
            <div class="icon-box-3d item-amber">
                <i class='bx bxs-calendar-exclamation'></i>
            </div>
            <div>
                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">Prazos Próximos</p>
                <h3 class="text-2xl font-black text-slate-800 dark:text-white leading-none"><?= count($prazosProximos) ?></h3>
            </div>
        </div>
    </div>

    <!-- Seção de Prazos Críticos -->
    <div class="sys-card !p-0 overflow-hidden">
        <div class="p-5 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between bg-slate-50/50 dark:bg-white/5">
            <h3 class="text-lg font-bold text-slate-800 dark:text-white flex items-center gap-2">
                <i class='bx bxs-time-five text-purple-600'></i>
                Agenda de Prazos (7 dias)
            </h3>
            <a href="<?= BASE_URL ?>/juridico/agenda" class="text-xs font-bold text-purple-600 hover:underline">Ver Agenda Completa</a>
        </div>
        
        <div class="overflow-x-auto">
            <table class="sys-table">
                <thead>
                    <tr>
                        <th class="w-32">Data Limite</th>
                        <th>Descrição do Prazo</th>
                        <th>Vínculo Processual</th>
                        <th class="text-center w-24">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($prazosProximos)): ?>
                        <tr>
                            <td colspan="4" class="text-center py-12 text-slate-400 italic">
                                <i class='bx bx-info-circle text-2xl block mb-2'></i>
                                Nenhum prazo processual crítico para os próximos dias.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($prazosProximos as $prazo): ?>
                            <tr class="hover:bg-slate-50 dark:hover:bg-white/5 transition-colors">
                                <td class="font-bold text-purple-600 dark:text-purple-400 uppercase text-xs">
                                    <?= date('d/m/Y', strtotime($prazo['data_prazo'])) ?>
                                </td>
                                <td class="text-slate-700 dark:text-slate-300 font-medium"><?= htmlspecialchars($prazo['descricao']) ?></td>
                                <td>
                                    <span class="sys-badge sys-badge-gray">Processo #<?= $prazo['processo_id'] ?></span>
                                </td>
                                <td class="text-center">
                                    <button class="p-1.5 text-slate-400 hover:text-purple-600 transition-colors" title="Ver Detalhes">
                                        <i class='bx bx-right-arrow-alt text-2xl'></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>